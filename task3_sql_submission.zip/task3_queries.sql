
-- Task 3: Writing Basic SELECT Queries
-- Internship: SQL Developer
-- Objective: Extract data using SELECT, WHERE, ORDER BY, and LIMIT

-- Sample schema (create this table before running queries)
CREATE TABLE Employees (
    EmployeeID INTEGER PRIMARY KEY,
    FirstName TEXT,
    LastName TEXT,
    Department TEXT,
    Salary INTEGER
);

-- Sample data
INSERT INTO Employees (EmployeeID, FirstName, LastName, Department, Salary) VALUES
(1, 'Alice', 'Roy', 'Sales', 40000),
(2, 'Bob', 'Smith', 'IT', 55000),
(3, 'Charlie', 'Brown', 'Sales', 35000),
(4, 'David', 'Lee', 'Marketing', 28000),
(5, 'Eva', 'Thomas', 'HR', 30000);

-- 1. SELECT all columns
SELECT * FROM Employees;

-- 2. SELECT specific columns
SELECT EmployeeID, FirstName, LastName FROM Employees;

-- 3. WHERE clause
SELECT * FROM Employees WHERE Department = 'Sales';

-- 4. WHERE with AND
SELECT * FROM Employees WHERE Department = 'Sales' AND Salary > 36000;

-- 5. WHERE with OR
SELECT * FROM Employees WHERE Department = 'Sales' OR Department = 'IT';

-- 6. LIKE operator
SELECT * FROM Employees WHERE FirstName LIKE 'A%';

-- 7. BETWEEN operator
SELECT * FROM Employees WHERE Salary BETWEEN 30000 AND 50000;

-- 8. ORDER BY ascending
SELECT * FROM Employees ORDER BY Salary ASC;

-- 9. ORDER BY descending
SELECT * FROM Employees ORDER BY Salary DESC;

-- 10. LIMIT
SELECT * FROM Employees ORDER BY Salary DESC LIMIT 3;

-- 11. ALIAS usage
SELECT FirstName || ' ' || LastName AS FullName, Department FROM Employees;

-- 12. DISTINCT values
SELECT DISTINCT Department FROM Employees;

-- 13. IN operator
SELECT * FROM Employees WHERE Department IN ('Sales', 'Marketing');
