
# Task 3 - SQL Developer Internship

## 🎯 Objective
Write SQL queries to extract and filter data using:
- SELECT, WHERE, AND, OR, LIKE, BETWEEN, ORDER BY, LIMIT, ALIAS, DISTINCT

## 🛠 Tools Used
- DB Browser for SQLite
- DB Fiddle (https://www.db-fiddle.com)
- GitHub

## 📁 Contents
- `task3_queries.sql`: Main SQL script
- `README.md`: Explanation and instructions

## 📸 Screenshots (Optional)
_Add execution screenshots here_

## 🔗 Submission Link
Paste your GitHub repo link here after uploading your `.sql` and `README.md`.

👉 [Submit Task 3 Here](https://forms.gle/8Gm83s53KbyXs3Ne9)
